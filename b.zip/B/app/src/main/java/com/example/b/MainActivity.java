package com.example.b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText Edtval1;
EditText Edtval2;

Button Btn1,Btn2,Btn3;
TextView resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Edtval1 = findViewById(R.id.edtNum1);
        Edtval2 = findViewById(R.id.edtNum2);
        Btn1 = findViewById(R.id.edtBtn1);
        resultado = findViewById(R.id.edtRes);
        Btn2 = findViewById(R.id.edtBtn2);
        Btn3 = findViewById(R.id.edtBtn3);
        Btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String caja1 = Edtval1.getText().toString();
                String caja2 = Edtval2.getText().toString();

                if (!caja1.equals("") && !caja2.equals("")){
                    int suma = Integer.parseInt(caja1) + Integer.parseInt(caja2);
                    resultado.setText(""+ suma);
                }else{
                    Toast.makeText(MainActivity.this, "Por favor ingrese el numero faltante", Toast.LENGTH_LONG).show();
                }
            }
        });
        Btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });

        Btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Edtval1.setText(null);
                Edtval2.setText(null);
                resultado.setText(null);
            }
        });
    }
}