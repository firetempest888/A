package com.example.b;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    EditText Edtval1;
    EditText Edtval2;

    Button Btn1, Btn2,Btn3;
    TextView resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Edtval1 = findViewById(R.id.edtNum1res);
        Edtval2 = findViewById(R.id.edtNum2res);
        Btn1 = findViewById(R.id.edtBtn1);
        resultado = findViewById(R.id.edtResres);
        Btn2 = findViewById(R.id.edtBtn2);
        Btn3 = findViewById(R.id.edtBtn3);

        Btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String caja1 = Edtval1.getText().toString();
                String caja2 = Edtval2.getText().toString();

                if (!caja1.equals("") && !caja2.equals("")){
                    int resta = Integer.parseInt(caja1) - Integer.parseInt(caja2);
                    resultado.setText(""+ resta);
                }else{
                    Toast.makeText(MainActivity2.this, "Por favor ingrese el numero faltante", Toast.LENGTH_LONG).show();
                }
            }


        });
        Btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
        Btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Edtval1.setText(null);
                Edtval2.setText(null);
                resultado.setText(null);
            }
        });
    }
    }
